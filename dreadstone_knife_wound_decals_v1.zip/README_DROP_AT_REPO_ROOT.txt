DREAD STONE BLACK — KNIFE WOUND DECAL PACK v1

DROP LOCATION
-------------
Unzip this archive at the repository root.
Final runtime directory:

public/assets/textures/combat/wounds/knife/

The archive already contains the full public/assets/... folder structure.

CONTENTS
--------
13 transparent 512x512 PNG decal variations:
- 7 puncture/deep-puncture variants
- 6 slash/deep-slash variants

Also included:
- knife_wound_decals.manifest.json
- knife_wound_decals_mapping.csv
- knife_wound_decals_preview.png

INTEGRATION INTENT
------------------
These images replace the generated circle/quad wound appearance only.
Keep the existing semantic hit detection, skinned-surface attachment, wound ownership,
bleeding logic, and Combat Director timing.

Selection should be deterministic per wound ID, filtered by wound type and severity,
then weighted-randomized using the manifest. Do not select a completely new visual every frame.

Texture settings:
- alpha transparency
- sRGB color map
- no emissive
- depth test enabled
- depth write disabled
- tiny surface bias / polygon offset
- preserve aspect ratio

Naming convention:
wound_knife_<family>_<shape>_<two-digit-variant>.png
